import TabNavigator from './src/routes/TabNavigator';

export default function App() {
  return (
    <TabNavigator/>
  );
}

