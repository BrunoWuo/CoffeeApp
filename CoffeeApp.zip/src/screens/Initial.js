import { View, Text } from 'react-native'
import React from 'react'

export default function Initial() {
  return (
    <View>
      <Text>Initial</Text>
    </View>
  )
}